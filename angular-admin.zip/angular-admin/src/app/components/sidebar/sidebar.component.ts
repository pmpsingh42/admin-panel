
import { Component, OnInit } from '@angular/core';
import { Sidebar } from './sidebar';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})


export class SidebarComponent implements OnInit {
  menuItems: any[];

  permissionSidebar = [];
  displaySidebar = [];
  constructor(private cookieService: CookieService, private router: Router) {}


  logout() {
    this.cookieService.delete('token');
    this.router.navigate(['']);
  }

  loadSidebar() {
    this.displaySidebar = [];
   this.permissionSidebar = JSON.parse(this.cookieService.get('permissions'));
    this.permissionSidebar.forEach((e1) => Sidebar.forEach((e2) => {

      if (e1 === e2.title) {
        this.displaySidebar.push(e2);
      }

    }));

  // Sidebar.forEach((e2)=>{
  //   this.displaySidebar.push(e2);
  // })

    console.log(this.displaySidebar);

    this.displaySidebar.forEach((data) => {
      if (data.path) {
        console.log(data.path);
      } else if (data.submenu) {
        data.submenu.forEach((data2) => {
          console.log(data2.path);
        });
      }

    });
  }

  ngOnInit() {
    this.loadSidebar();
    this.menuItems = this.displaySidebar;

  }

}

