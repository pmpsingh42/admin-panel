import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editadmin',
  templateUrl: './editadmin.component.html',
  styleUrls: ['./editadmin.component.scss']
})
export class EditadminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
