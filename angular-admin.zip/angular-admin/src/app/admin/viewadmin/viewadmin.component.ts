import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewadmin',
  templateUrl: './viewadmin.component.html',
  styleUrls: ['./viewadmin.component.scss']
})
export class ViewadminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
