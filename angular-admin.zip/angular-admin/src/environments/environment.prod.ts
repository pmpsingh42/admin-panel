export const environment = {
  production: false,
  staging:false,
  development:true,
  apiUrl: 'http://localhost:3100'
};
