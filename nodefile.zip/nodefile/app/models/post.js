'use strice'; 

const  mongoose         =require('mongoose'),
       Schema           =mongoose.Schema;
       
       

       
var postSchema= new Schema({

    title:        String,
    image:        String,
    short_desc:   String,  
    content:      String,  
    meta_title:   String,            
    meta_keyword: String, 
    meta_desc   : String,   
    location    : String,
    order       : String,
    status      : String,
    type        : String,
    trash       :{
                    type:Boolean,
                    default:false

                    }
    

},{
    timestamps:{
        createdAt:'create_at',
        updatedAt:'updated_at'
    }
});

module.exports=mongoose.model('post',postSchema);