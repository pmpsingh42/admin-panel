'use strict';

const DS="/",
      PORT=3100,
      __DB="angular";
         

      module.exports={

        server: {
            PORT: PORT
        },
        API:{
          site:'/api/',
          admin:'/admin_api'
        },
        db:{
          name:__DB,
          URL: "mongodb://localhost/"+__DB
        },
        debug_mongo: true,
        secret : new Buffer("jlskadjfj@#$@#$@#$fo78jdljsdlfjsldfj@!#$@#$465i3488392746n!@&$%#45").toString('base64'),
         
      };