'use strict';

const   path        = require('path'),
        Admin       = require(path.resolve('./app/models/admin'));


class IndexController
{       
    checkAdmin(req,res){
        console.log(res);
        Admin.findOne({type:1},(err, result)=>{
            if(!result){
            
                var admin={
                    firstname: 'john',
                    lastname: 'doe',
                    email:'flexsin@yopmail.com',
                    mobile:'123456',
                    type:1,
                    password:"123456"                
                };

                var user=new Admin(admin);
                user.save((err, result)=>{
                    if(err){
                        //res.json({success:false, message:err});
                    }
                    else if(result){
                        //res.json({success:true, message:"suceess"})
                    }
                    else{
                        //res.json({success:false, message:"error occurred while inserting the data"});
                    }
                })


            }
        })
    }
}

    module.exports = IndexController;




