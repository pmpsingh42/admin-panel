'use Strict'

const path               = require('path'),
      objectId           = require('mongoose').Types.ObjectId,  
      env                = require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),       
      Post               = require(path.resolve('./app/models/post')),
      secret             = new Buffer(env.secret).toString('base64'),
      formidable         = require('formidable'),
      multer             = require('multer'),
      upload             = multer({dest: 'data/'}),
      decode             = require(path.resolve('./app/config/libs/jwt'))
      mv                 = require('mv'),
      shortid            = require('shortid');  
      fs                 = require('fs-extra');
     
     
class PostController{

            constructor(){

                this.createPost =   this.createPost.bind(this);
                this.addPostWithImage = this.addPostWithImage.bind(this);
                this.postList = this.postList.bind(this);
                this.removeSinglePost = this.removeSinglePost.bind(this);
                this.getSinglePost  =   this.getSinglePost.bind(this);
                this.removeMultiplePost = this.removeMultiplePost.bind(this);
                this.editPost = this.editPost.bind(this);
                this.editPostWithImage = this.editPostWithImage.bind(this);
                this.changeStatus=this.changeStatus.bind(this);
            }

            createPost(req, res){

                decode.run(req,secret,(body)=>{

                    let obj=req.body;

                    Post.create({

                        title:obj.title,
                        short_desc:obj.short_desc,
                        content:obj.content,
                        meta_title:obj.meta_title,
                        meta_keyword:obj.meta_keyword,
                        meta_desc: obj.meta_desc,
                        location:obj.location,
                        order: obj.order,  
                        status:obj.status,
                        type:obj.type

                    },(error, result)=>{
                        if(error){
                            res.json({success:false, message:error})
                        }else{
                            if(result){
                                res.json({success:true, message:"Post Successfully Saved"})
                            }else{
                                res.json({success:false, message:"error occurred while saving data"})
                            }
                        }
                    })

                })
                
            }
            
        
            
        addPostWithImage(req,res){
            
            decode.run(req, secret, (body) => {


                var form = new formidable.IncomingForm();
           
           
                form.parse(req, function(err, fields, files) {
                    
                  
                    console.log(fields);
           
                    let file = files.file,
                        dir, child_dir, tmp_path, target_path;

                    // console.log(file);
           
                    tmp_path = file.path;
           
                    console.log(fields)
                    
                    var id = shortid.generate()
                    console.log(id);
           
                    dir = `./uploads`;
                    child_dir = "/"+fields.type;
           
                    var filename = file.name,
                        filename = filename.split('.'),
                        fileextension = filename[filename.length - 1];        
           
           
                    if (!fs.existsSync(dir)) {
                        fs.mkdirSync(dir);
                    } else if (!fs.existsSync(dir+"/"+child_dir)) {
           
                        fs.mkdirSync(dir+"/"+child_dir)
                    }
           
                    target_path = `${dir}/${child_dir}/${id}.${fileextension}`;
           
                    mv(tmp_path, target_path, (err) => {
           
           
                        if (err) {
                            res.json({
                                success: false,
                                message: err
                            });
                        } else {
           
                            if (fields) {
           
                                var obj = fields;
           
                                Post.create({
           
                                    title: obj.title,
                                    short_desc: obj.short_desc,
                                    content: obj.content,
                                    meta_title: obj.meta_title,
                                    meta_keyword: obj.meta_keyword,
                                    meta_desc: obj.meta_desc,
                                    location: obj.location,
                                    image: child_dir+"/"+id + "." + fileextension,
                                    order: obj.order,
                                    status: obj.status,
                                    type: obj.type
           
                                }, (error, result) => {
                                    if (error) {
                                        res.json({
                                            success: false,
                                            message: error
                                        })
                                    } else {
                                        if (result) {
                                            res.json({
                                                success: true,
                                                message: "Post Successfully Saved"
                                            })
                                        } else {
                                            res.json({
                                                success: false,
                                                message: "error occurred while saving data"
                                            })
                                        }
                                    }
                                })
           
                            } else {
                                res.json({
                                    success: true,
                                    message: "file uploaded",
                                    image: id + ".jpg"
                                });
                            }
                        }
           
                    })
           
           
                });
           
            })
        }  


            // api for post list with pagination
            postList(req, res){

                let obj=req.query;

                // set limit
                let limit= parseInt(obj.limit) || 10,
                    offset= parseInt((obj.page-1)*limit),
                    match={type:obj.type, trash:false};


                Post.aggregate([{

                    $facet:{
                        count:[{
                            $match:match
                        },{
                            $project:{title:1, count:"0"}
                        },{
                            $group:{

                                _id:"$count",
                                total:{$sum:1}
                            }
                        }],
                        data:[{

                            $match:match
                        },{
                            $skip:offset
                        },{
                            $limit:limit
                        },{
                            $project:{
                                title:1,
                                status:1, 
                                short_desc:1,
                                meta_keyword:1                               
                            }
                        }]
                    }

                }],(error, result)=>{
                    if(error){
                        console.log(error);
                        res.json({success:false})
                    }else{
                        if(result){
                          res.json({success:true, data:result[0]})
                        }else{
                            res.json({success:false, message:"error"});
                        }    
                    }
                })


            }

            // delete the single post 
            removeSinglePost(req, res){

                decode.run(req, secret,(data) => {

                    let obj=req.body;
                
                    Post.findOneAndUpdate({
                        
                        _id:objectId(obj._id)
                    },{
                        $set:{trash:true
                    } 
                },{
                        new:true
                    },(err, result)=>{

                        console.log(result);
                        console.log(err);

                        if(err){
                            res.json({success:false, message:err})
                        }else{

                            if(result){

                                res.json({success:true})
                            }else{
                                res.json({success:false, message:"ejksdfhksdjh"})
                            }
                        }
                    })

                })

            }

            //get single data for edit
            getSinglePost(req, res){

                decode.run(req, secret,(data)=>{

                    let obj=req.body;

                    Post.findOne({
                        _id:objectId(obj._id)},(err, result)=>{
                            if(err){
                                res.json({success:false, message:err})
                            }else{
                                if(result){
                                    res.json({success:true, data:result});
                                }else{
                                    res.json({success:false});
                                }
                            }
                        })
                })
                

            }

            // remove multiple post 
            removeMultiplePost(req,res){

                decode.run(req, secret, (data)=>{
                    let obj=req.body;
                        console.log(obj.map(x=> x._id));
                   Post.update({_id:{$in:obj.map(x=> x._id)}},{
                       $set:{trash:true}},{
                           multi:true
                       },(err,result)=>{
                           if(err){
                               res.json({success:false, message:err})
                           }else{
                               if(result){
                                   res.json({success:true})
                               }else{
                                   res.json({success:false})
                               }
                               
                           }
                       }
                   ) 

                   console.log(obj.map(x=> x._id));
                                 
                })                
            }

            changeStatus(req,res){
                decode.run(req, secret,(data)=>{
                    let obj=req.body;
                    Post.update({_id:{$in:obj.map(x=>x._id)}},{

                        $set:{status:req.query.status}},{
                            multi:true
                        },(error, result)=>{
                            if(error){
                                res.json({success:false, message:error})
                            }else{
                                if(result){
                                    res.json({success:true})
                                }else{
                                    res.json({success:false})
                                }
                            }
                        })
                })
            }


        editPost(req, res){

            decode.run(req, secret,(data)=>{

                let obj=req.body

                Post.findOneAndUpdate({_id:obj._id},{

                    title:obj.title,
                    short_desc:obj.short_desc,
                    content:obj.content,
                    meta_title:obj.meta_title,
                    meta_keyword:obj.meta_keyword,
                    meta_desc: obj.meta_desc,
                    location:obj.location,
                    order: obj.order,  
                    status:obj.status,
                    type:obj.type

                },{
                    new:true
                },(err, result)=>{
                    if(err){
                        res.json({success:false, message:err})
                    }else{
                        if(result){
                            res.json({success:true})
                        }else{
                            res.json({success:false});
                        }
                    }
                })

            })
        }

        editPostWithImage(req, res){

            decode.run(req, secret,(data)=>{

                
                var form = new formidable.IncomingForm();

                form.parse(req, function(err, fields, files){

                    let file=files.file,
                    dir, child_dir, tmp_path, target_path;

                    console.log(file)
                    tmp_path=file.path;
                    console.log(fields);

                    var id=shortid.generate()

                    dir ='./uploads';
                    child_dir="/"+fields.type;

                    var filename=file.name,
                        filename = filename.split('.'),
                        fileextension= filename[filename.length-1];

                        if(!fs.existsSync(dir)){
                            fs.mkdirSync(dir);
                        }else if(!fs.existsSync(dir+"/"+child_dir)){
                        
                            fs.mkdirSync(dir+"/"+child_dir)
                        }else{

                        }

                        target_path=  `${dir}/${child_dir}/${id}.${fileextension}`;

                        mv(tmp_path,target_path,(err)=>{

                            if(err){
                                res.json({
                                    success:false,
                                    message:err
                                });
                            }else{
                                if(fields){
                                    var obj =fields;

                                    Post.findOneAndUpdate({_id:obj._id},{

                                        title:obj.title,
                                        short_desc:obj.short_desc,
                                        content:obj.content,
                                        meta_title:obj.meta_title,
                                        meta_keyword:obj.meta_keyword,
                                        meta_desc: obj.meta_desc,
                                        location:obj.location,
                                        order: obj.order,  
                                        status:obj.status,
                                        image:child_dir+"/"+id + "." + fileextension,
                                        type:obj.type
                
                                    },{
                                        new:true
                                    },(err, result)=>{
                                        if(err){
                                            res.json({success:false, message:err})
                                        }else{
                                            if(result){
                                                res.json({success:true})
                                            }else{
                                                res.json({success:false});
                                            }
                                        }
                                    })

                                    
                                }
                            }

                        })                    

                })
                
            })
        }

}

module.exports=PostController;