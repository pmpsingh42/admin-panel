'use strict';

const   path        = require('path'),
        env         = require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),  
        secret      = new Buffer(env.secret).toString('base64'),
        decode      = require(path.resolve('./app/config/libs/jwt')),
        Role        = require(path.resolve('./app/models/adminrole'));


class RoleController{
    
    constructor(){

        this.addRole =   this.addRole.bind(this);
        this.adminRoleList = this.adminRoleList.bind(this);
        this.deleteRole = this.deleteRole.bind(this);
        this.deleteSingleRole = this.deleteSingleRole.bind(this);
        this.getSingleRole = this.getSingleRole.bind(this);
        this.editRole = this.editRole.bind(this);
        this.rolelist = this.rolelist.bind(this);
       
    }


    addRole(req,res){

        decode.run(req, secret,(data)=>{

            let obj = req.body

            Role.create({
                 role: obj.role,
                 status:obj.status,
                 permissions:obj.permissions

            },(error, result)=>{
                if(error){
                    res.json({success:false, message:error});
                }else{
                    if(result){
                        res.json({success:true});
                    }else{
                        res.json({success:false});
                    }
                }
            })
        })
    }   

    adminRoleList(req, res){
        decode.run(req, secret,(data)=>{
                let obj=req.query
                let limit= parseInt(obj.limit) || 10,
                    offset= parseInt((obj.page-1)*limit),
                    match={trash:false};


                Role.aggregate([{

                    $facet:{
                        count:[{
                            $match:match
                        },{
                            $project:{role:1, count:"0"}
                        },{
                            $group:{

                                _id:"$count",
                                total:{$sum:1}
                            }
                        }],
                        data:[{

                            $match:match
                        },{
                            $skip:offset
                        },{
                            $limit:limit
                        },{
                            $project:{
                                role:1,
                                status:1, 
                                permissions:1
                                                               
                            }
                        }]
                    }

                }],(error, result)=>{
                    if(error){
                        console.log(error);
                        res.json({success:false})
                    }else{
                        if(result){
                          res.json({success:true, data:result[0]})
                        }else{
                            res.json({success:false, message:"error"});
                        }    
                    }
                })

        })
    }



    deleteSingleRole(req,res){

        decode.run(req, secret,(data)=>{
                let obj=req.body;
                console.log(obj);
            Role.findOneAndUpdate({_id:obj._id},{

                trash:true
            },{
                new:true 
            },(err, result)=>{
                if(err){
                    res.json({success:false, message:err})
                }else{
                    if(result){
                        res.json({success:true})
                    }else{
                        res.json({success:false})
                    }

                }
            })

        })

    }




    deleteRole(req,res){

        decode.run(req, secret,(data)=>{
                let obj=req.body;
                console.log(obj);
            Role.update({_id:{$in:obj.map(x=>x._id)}},{

                trash:true
            },{
                multi:true 
            },(err, result)=>{
                if(err){
                    res.json({success:false, message:err})
                }else{
                    if(result){
                        res.json({success:true})
                    }else{
                        res.json({success:false})
                    }

                }
            })

        })

    }

    getSingleRole(req, res){

        decode.run(req, secret, (data)=>{
            
            let obj=req.body;

            Role.findOne({_id:obj._id},(error,result)=>{

                if(error){
                    res.json({success:false, })
                }else{
                    if(result){
                        res.json({success:true, result:result})
                    }else{
                        res.json({success:false})
                    }
                    
                }

            })
        })
        
    }

    editRole(req, res){

        decode.run(req, secret, (data)=>{

            let obj = req.body;

            Role.findOneAndUpdate({_id:obj._id},{
                 role: obj.role,
                 status:obj.status,
                 permissions:obj.permissions

            },{
                new:true
            },(error, result)=>{
                if(error){
                    res.json({success:false});
                }else{
                    if(result){
                        res.json({success:true});
                    }else{
                        res.json({success:false})
                    }
                }
            })


        })
    }    

    rolelist(req, res){

        decode.run(req, secret ,(data)=>{

            let obj=req.body;

            Role.find({trash:false},
                {role:1},
                (error, result)=>{

                    if(error){
                        res.json({success:false, error:error})
                    }else{
                        if(result){
                            res.json({success:true, result:result})
                        }else{
                            res.json({success:false})
                        }
                    }

            })

        })

    }
}

module.exports = RoleController;